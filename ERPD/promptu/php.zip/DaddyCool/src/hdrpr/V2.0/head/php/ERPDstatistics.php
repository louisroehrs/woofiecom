<HTML>
<TITLE>ERPD - Show System Statistics</TITLE>
<BODY>
<meta http-equiv="refresh" content="10">
<h2>Show the counters of the ERPD system</h2>
<pre>
<?
echo passthru("service erpd status");
?>
</pre>
Click on BACK to return to the previous page...
</BODY>
</HTML>

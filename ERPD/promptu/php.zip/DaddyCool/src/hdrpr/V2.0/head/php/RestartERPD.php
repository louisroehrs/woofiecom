<HTML>
<TITLE>ERPD - Restart the ERPD System</TITLE>
<BODY>
<h2>Restarting the ERPD system daemons</h2>
<pre>
<?
echo passthru("service erpd restart");
?>
</pre>
Click on BACK to return to the previous page...
</BODY>
</HTML>

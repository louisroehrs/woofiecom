<HTML>
<TITLE>ERPD - Show System Status</TITLE>
<BODY>
<h2>Show the status of the ERPD system</h2>
<pre>
<?
echo passthru("service erpd status");
?>
</pre>
Click on BACK to return to the previous page...
</BODY>
</HTML>

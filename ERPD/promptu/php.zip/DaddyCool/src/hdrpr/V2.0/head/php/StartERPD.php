<HTML>
<TITLE>ERPD - Start the ERPD System</TITLE>
<BODY>
<h2>Starting the ERPD system daemons</h2>
<pre>
<?
echo passthru("service erpd start");
?>
</pre>
Click on BACK to return to the previous page...
</BODY>
</HTML>

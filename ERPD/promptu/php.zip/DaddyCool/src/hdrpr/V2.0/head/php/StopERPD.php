<HTML>
<TITLE>ERPD - Stop the ERPD System</TITLE>
<BODY>
<h2>Stopping the ERPD system daemons</h2>
<pre>
<?
echo passthru("service erpd stop");
?>
</pre>
Click on BACK to return to the previous page...
</BODY>
</HTML>

#!/usr/local/bin/perl
#
# change-password.pl -- Change the password hard-coded in add-a-date.pl
#
# Written by Collin Forbes in August, 1996.
#
# This is not a CGI script.  It's not an interactive script either.  
# It's a very specialized filter to look for a particular line in
# standard input, and modify it.
#
# To change the password in add-a-date.pl to "password" type:
#
#	"cat add-a-date.pl | change-password.pl password > file.pl"
#
# Then rename "file.pl" to "add-a-date.pl".  You will have to have write
# access to the directory you are working in, and might have to specify a
# full path to the add-a-date.pl script.  To rename the script back to the
# original name, you will need write access to the script.
#
#
# Configuration Section ------------------------------------------
#

$password_line = '\$user_passwd =';
#
# This abomination is the beginning of the line where the encrypted password
# is hard-coded into the add-a-date.pl script.  You won't have to change it.
#
# End Configuration Section --------------------------------------

main: {

    $password = $ARGV[0];
    $encrypted_password = &encrypt_password($password);

    while (<STDIN>) {
	$_ =~ s/^($password_line).*/$1 \"$encrypted_password\"\;/;
	print $_;
    }
}

sub encrypt_password {
#
# Returns an encrypted password.
#
    local($password, $salt, $encrypted_password);

    $password = $_[0];
    $salt = "Ab";	 			# hard-coded salt
    $encrypted_password = crypt($password, $salt);

    $encrypted_password;			# Return value for subroutine
}

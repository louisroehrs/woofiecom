#!/usr/local/bin/perl
#
# calendar.pl -- A CGI script to display a calendar of events
#
# Version 2.2, written by Collin Forbes in August, 1996.
#
# Before you use this script in a commercial manner, please contact me
# to negotiate a license.  My email address is collinf@kuoi.asui.uidaho.edu.
#
# Use this script as the GET action to a form with the following fields.
# You can also hard-code the parameters into a URL instead of using a form.
#
# <input name=file> (sort-of-required) The "nickname" of the configuration 
#	file to use.  This file contains configuration information as well
#	as dates or events in the following format:
#		"year<tab>month<tab>day<tab>event<newline>"
#	You can use the keyword "any" in any of the fields to make an
#	event repeat.  You can also use ranges, such as 96-97 or 12-14 to
#	make an event run during a range of dates.
#
# <input name=month> (option) The month to display.  Use "current", "next",
#	"previous" or the name of the month, eg "august".  The default
#	behavior is to display the current month.
#
# <input name=year> (optional) The year of the month to display.  Use
#	"current", "next", "previous", or the two-letter year between
#	1970 and 2049.  The default is the current year.
#
#
# Configuration Section ------------------------------------------
#

%configuration_file = (
	'' => '/home/collinf/public_html/scripts/calendar-2.2/config.txt',
	'calendar' => '/home/collinf/public_html/scripts/calendar-2.2/config.txt',
	'padded_cells' => '/home/collinf/public_html/scripts/calendar-2.2/config.txt',
	);
#
# You can use the different "nicknames" to point to different configuration
# files.  The "=>" is a perl5 synonym for a comma.  Change them to commas
# to use this script under perl4.  You will also have to change various
# "and" boolean operators to "&&" in numerous if statements.
#

$token = '<!-- #TOKEN -->';
#
# $token is the text in the HTML template file which marks where the 
# calendar will be inserted.  Without a token in the file, the script
# will not insert a calendar.  This is just a default, and you can easily
# override this value in your configuration file.
#

$version = "v2.2";
#
# Version 2.2 was released 08/19/96
#
# End Configuration Section --------------------------------------

# Begin Global Array Section -------------------------------------
# 
@month = (	'January','February','March','April', 'May','June','July',
		'August','September','October','November','December' );
# 
@days_in_mon = (	'31', '28', '31', '30', '31', '30', '31',
			'31', '30', '31', '30', '31'	);
#
# Thirty-one days hath Jan, March, May, July, Aug, Oct, and Dec.  
# Leap years are handled in &print_table and &print_non_table subroutines.
#
# End Global Array Section ---------------------------------------

main: {

    @pairs = split(/&/, $ENV{'QUERY_STRING'} );
    foreach $pair (@pairs) {
	($name, $value) = split(/=/, $pair);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	$name =~ tr/+/ /;
	$name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	$FORM{$name} = $value;
    }

    ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdist) = localtime(time);
    #
    # Do we want something other than the current month?
    #
    $form_mon = $FORM{'month'};
    if (    $form_mon =~ /next/i )	{ $mon++; }
    elsif ( $form_mon =~ /prev/i )	{ $mon--; }    # You *can* get away
    elsif ( $form_mon =~ /jan/i )	{ $mon = 0; }  # with using a three
    elsif ( $form_mon =~ /feb/i )	{ $mon = 1; }  # letter abbreviation
    elsif ( $form_mon =~ /mar/i )	{ $mon = 2; }  # of the month instead
    elsif ( $form_mon =~ /apr/i )	{ $mon = 3; }  # of the full name.
    elsif ( $form_mon =~ /may/i )	{ $mon = 4; }  #
    elsif ( $form_mon =~ /jun/i )	{ $mon = 5; }  # This 'bulletproofs' 
    elsif ( $form_mon =~ /jul/i )	{ $mon = 6; }  # the script to some
    elsif ( $form_mon =~ /aug/i )	{ $mon = 7; }  # extent and makes the
    elsif ( $form_mon =~ /sep/i )	{ $mon = 8; }  # script run right even
    elsif ( $form_mon =~ /oct/i )	{ $mon = 9; }  # if you don't know how
    elsif ( $form_mon =~ /nov/i )	{ $mon = 10; } # to spell the months.
    elsif ( $form_mon =~ /dec/i )	{ $mon = 11; }
    # "$mon" is already defined as the current month for any other input.

    #
    # Do we want something other than the current year?
    #
    $form_year = $FORM{'year'};
    if ( $form_year ) {
        if ( $form_year =~ /next/i )	{ $year++; }
        elsif ( $form_year =~ /prev/i )	{ $year--; } # abbreviations again
        elsif ( $form_year =~ /^\d+$/ )	{ $year = $form_year; } 
        # "$year" is already defined as the current year for any other input.
    }

    $file_nickname = $FORM{'file'};	# Configuration filename
    @calendar_file = &receive_file_contents($file_nickname);
    
    &get_configuration_information(@calendar_file);	# Creates %CONFIG
    &get_date_information(@calendar_file);		# Creates %DATE

    open(TEMPLATE_FILE, $CONFIG{'template'} ) 
				|| &error_html('opening template file');

    print "Content-type: text/html\n\n";

    if ( $CONFIG{'token'} ) { $token = $CONFIG{'token'}; }

    while (<TEMPLATE_FILE>) {
	if ( s/^$token$//i ) {				  # Replace the token
	    if ( $ENV{'HTTP_USER_AGENT'} =~ m/Lynx/i ) {  # with a calendar
		&print_non_table(@calendar_file);	  # for lynx or for
	    }						  # other browsers
	    else { &print_table(@calendar_file); }
	}
	else { print $_; }				  # otherwise print
    }
    close(TEMPLATE_FILE);
} 

sub print_table {
#   
# Prints the HTML table.  Adds "spacer gifs" to the cells if "spacer_gif=" 
# is specified in the configuration file. 
#   
# Global variables:	Uses "$mon", "$year", "@month",
#			"@days_in_mon", and "$leap_year"
#   
    local (	@calendar_file, $spacer_gif, @date_list, $printed_year,
		$first_day, $days_in_this_month, $week_count, $days_left,
		$head_color, $cell_color	);
    
    @calendar_file = @_;

    #
    # A 1x75 (or whatever) transparent graphic can be used to pad the
    # table cells.  A hack to make the calendar appear to have cells of
    # a specific size.
    #
    $spacer_gif = $CONFIG{'spacer_gif'};

    #
    # Set the background colors for the head (the month and days) and
    # cells of the tables.  "White" is a predefined color in HTML 3.2
    #
    if ( $CONFIG{'head_color'} ) { $head_color = $CONFIG{'head_color'}; }
    else { $head_color = "white"; }
    if ( $CONFIG{'cell_color'} ) { $cell_color = $CONFIG{'cell_color'}; }
    else { $cell_color = "white"; }


    $first_day = &perpetual_calendar($mon, $year);
    $printed_year = $year + 1900;
    
    &credit_comment($version);
    print "<p align=center><table border>";
    print "<tr><th colspan=7 bgcolor=\"$head_color\">";
    print "<big>$month[$mon] $printed_year</big></th></tr>\n";

    #
    # If the month starts on sunday, there won't be any room to put monthly
    # notices in the first cell of the calendar.  Instead, we'll make a new
    # row in the header for a monthy notice if one exists.
    #
    $encoded_date = $year . '.' . $mon . '.' . 'any';
    if ( ($first_day == 0) and $DATE{$encoded_date} ) { 
	print "<tr><td colspan=7 bgcolor=\"$head_color\"";
	print "$DATE{$encoded_date}&nbsp\;</td></tr>";
    }

    print "<tr><th bgcolor=\"$head_color\"><big>Sunday</big></th>\n";
    print "<th bgcolor=\"$head_color\"><big>Monday</big></th>\n";
    print "<th bgcolor=\"$head_color\"><big>Tuesday</big></th>\n";
    print "<th bgcolor=\"$head_color\"><big>Wednesday</big></th>\n";
    print "<th bgcolor=\"$head_color\"><big>Thursday</big></th>\n";
    print "<th bgcolor=\"$head_color\"><big>Friday</big></th>\n";
    print "<th bgcolor=\"$head_color\"><big>Saturday</big></th></tr>\n";

    #
    # Beginning of the cells
    #
    print "<tr>";

    #
    # Put events which affect the entire month in the space before the days?
    #
    if ( $first_day != 0 ) { 				
        print "<td bgcolor=\"$cell_color\" colspan=$first_day>";
	print "$DATE{$encoded_date}&nbsp\;</td>";
    }

    #
    # Initialize some variables for the table.
    #
    $week_count = $first_day;
    $days_in_this_month = $days_in_mon[$mon];
    if ( ($mon == 1) and $leap_year ) { $days_in_this_month++; }
    #
    # Print the "meat" of table.
    #
    for ($day_count = 1; $day_count <= $days_in_this_month; $day_count++) {
        print "<td valign=top width=\"15%\" bgcolor=\"$cell_color\">";
        if ( $spacer_gif ) {
            print "<img src=$spacer_gif align=right alt=\"\">";
        }
        print "<big>$day_count</big>";
	$encoded_date = $year . '.' . $mon . '.' . $day_count;
        print "$DATE{$encoded_date}"; 
        print "</td>\n";

        if ( ++$week_count == 7 ) { print "</tr>\n<tr>"; $week_count = 0 };
	# here we have bad HTML, because if the month ends on saturday,
	# there will be an extra <tr></tr> at the end of the table.  Bad.
    }
    #
    # Close the table.
    #
    if ( $week_count != 0 ) {
	$days_left = 7 - $week_count;
	print "<td bgcolor=\"$cell_color\" colspan=$days_left>&nbsp\;</td>";
	# "&nbsp;" is to keep the browser from collapsing an empty cell
    }
    print "</tr></table>\n";
    &credit_comment($version);

    # There is no meaningful return value for this subroutine.
}   

sub print_non_table {
#   
# Prints the calendar in list form.  For compatibility with lynx browsers.
#   
# Global variables:	Uses "@days_in_mon", "$leap_year", "@month",
#			"$mon" and "$year"
# 
    local (@calendar_file, $printed_year, $days_in_this_month);
    
    @calendar_file = @_;
    $printed_year = $year + 1900;

    &credit_comment($version);
    print "<h2>$month[$mon] $printed_year</h2>\n";

    #
    # Here, monthly events are just put at the top of the calendar.  Simpler.
    #
    $encoded_date = $year . '.' . $mon . '.' . 'any';
    print "$DATE{$encoded_date}<p>\n";
    print "<ol>\n";

    $days_in_this_month = $days_in_mon[$mon];
    if ( ($mon == 1) and $leap_year ) { $days_in_this_month++; }

    for ($day_count = 1; $day_count <= $days_in_this_month; $day_count++) {
        print "<li>";
	$encoded_date = $year . '.' . $mon . '.' . $day_count;
        print "$DATE{$encoded_date}";
    }
    print "</ol>\n";
    &credit_comment($version);

    # There is no meaningful return value for this subroutine.
}

sub get_date_information {
#
# Takes the input from the configuration file (in list form) and looks for
# lines that aren't configuration info.  Then it puts this information into
# an associative array (global) for later use.  
#
# Dates are keys to the array in the format Year<dot>Mon<dot>Day, where
# "Year" is 70-149 (!!), "Mon" is 0-11 (!), and "Day" is 1-31. 
#
# Global variables:	Creates %DATE
#
    local(@date_information, $line, @dates, $date, $name, $value);

    @date_information = @_;
    foreach $line (@date_information) {			   # Look for lines 
	if ( $line =~ m/^\w+\t/ ) { push(dates, $line); }  # with date info 
    }

    foreach $date (@dates) {
	( $event_year, $event_mon, $event_day, $event ) = split(/\t/, $date);

	if ( $event_year =~ m/any/i ) { $event_year = $year; }
	if ( $event_mon =~ m/any/i ) { $event_mon = $mon; }

	$event_day =~ s/any/any/i;	# Convert any "Any" to lower case
        $event_mon--;			# Decrement to make it 0-11

	if ( $event_day =~ m/-/i ) { &split_date_ranges($date); }
	else {
	    $encoded_date = $event_year . '.' . $event_mon . '.' . $event_day;
	    $DATE{$encoded_date} = $DATE{$encoded_date} . '<p>' . $event;
	}
    }

    # There is no meaningful return value for this subroutine.
}

sub split_date_ranges {
#
# Called from &get_date_informaton, this subroutine splits date ranges 
# into separate days.  Then it adds them to the %DATE array.
#
# Global variables:	Modifies (adds to) %DATE
#
    local ( $date_line, $event_year, $event_mon, $event_day, $event,
	    $begin, $end, $day );

    $date_line = $_[0];
    ( $event_year, $event_mon, $event_day, $event ) = split(/\t/, $date_line);

    $event_mon--;			# Decrement to make it 0-11

    ( $begin, $end ) = split(/-/, $event_day); 
    foreach $day ($begin .. $end) {
	$encoded_date = $event_year . '.' . $event_mon . '.' . $day;
	$DATE{$encoded_date} = $DATE{$encoded_date} . '<p>' . $event;
    }
    # There is no meaningful return value for this subroutine.
}

sub get_configuration_information {
#
# Takes the input from the configuration file (in list form) and looks for
# lines that aren't dates/events.  Then it puts this information into an
# associative array (global) for later use.
#
# Global variables:	Creates %CONFIG
#
    local(@config_information, $line, @pairs, $pair, $name, $value);

    @config_information = @_;
    foreach $line (@config_information) {		   # Look for lines
	if ( $line =~ m/^\w+\=/ ) { push(pairs, $line); }  # with config info
    }

    foreach $pair (@pairs) {
	($name, $value) = split(/=/, $pair);
	if ( $value ) { 
	    chop($value);
	    $CONFIG{$name} = $value;
	}
    }

    # There is no meaningful return value for this subroutine.
}

sub perpetual_calendar {
#
# This perpetual calendar was detailed on a wallet-sized card published
# by Arthur A. Merrill and Popular Science in 1952.
#
# This subroutine takes the month and year as arguments and returns what
# "type" of month it is [0-6].  Not coincidently, this is also the day of
# the week the month starts on, where Sunday is a "0" and Saturday is a "6".
#
# Global variables	creates "$leap_year"
#

    local(	$mon, @month, $year, %year_code, $leap_years,
		$perpetual_calendar, $calendar	);

    ( $mon, $year ) = @_;

    @month = (	'January',	'February',	'March',	'April',
		'May',		'June',		'July',		'August', 
		'September',	'October',	'November',	'December' ); 

    #
    # Year codes provided for 1970-2059.  The codes repeat every 150 years.
    #
    # For some reason unknown to me, perl returns years before 1999 as
    # two digit numbers, and years after 2000 as three digit numbers.
    #
    %year_code = (
		'70','D', '71','E', '72','M', '73','A', '74','B',
		'75','C', '76','K', '77','F', '78','G', '79','A',

		'80','I', '81','D', '82','E', '83','F', '84','N', 
		'85','B', '86','C', '87','D', '88','L', '89','G',  
  
		'90','A', '91','B', '92','J', '93','E', '94','F',
		'95','G', '96','H', '97','C', '98','D', '99','E',
    
		'100','M', '101','A', '102','B', '103','C', '104','K',
		'105','F', '106','G', '107','A', '108','I', '109','D',
    
		'110','E', '111','F', '112','N', '113','B', '114','C',
		'115','D', '116','L', '117','G', '118','A', '119','B',
        
		'120','J', '121','E', '122','F', '123','G', '124','H',
		'125','C', '126','D', '127','E', '128','M', '129','A',
 
		'130','B', '131','C', '132','K', '133','F', '134','G',
		'135','A', '136','I', '137','D', '138','E', '139','F',
    
		'140','N', '141','B', '142','C', '143','D', '144','L',
		'145','G', '146','A', '147','B', '148','J', '149','E', );

    if ( $month[$mon] eq 'January' ) { 
	if ( $year_code{$year} =~ /[EL]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[GN]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[DK]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[AH]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[CJ]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[BI]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[FM]/ ) { $calendar = 6 }
    } 
    elsif ( $month[$mon] eq 'February' ) {  
	if ( $year_code{$year} =~ /[BI]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[DK]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[AH]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[EL]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[GN]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[FM]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[CJ]/ ) { $calendar = 6 }


	#
	# So here's a kludge I used.  Instead of looking up the actual method
	# of figuring leap years is, I figured out the leap years 1970-2048.
	#
	#
	$leap_years = 	"1972 1976 1980 1984 1988 1992 1996 2000 2004 2008" .
			"2012 2016 2020 2024 2028 2032 2036 2040 2044 2048";
	#
	# "$leap_year" is a global variable.
	#
	if ( $leap_years =~ /$year/ ) { $leap_year = 'True'; }
	else { $leap_year = 'False'; }

    }
    elsif ( $month[$mon] eq 'March' ) { 
	if ( $year_code{$year} =~ /[BH]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[DJ]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[AN]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[EK]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[GM]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[FL]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[CI]/ ) { $calendar = 6 }
    }
    elsif ( $month[$mon] eq 'April' ) {  
	if ( $year_code{$year} =~ /[FL]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[AN]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[EK]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[BH]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[DJ]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[CI]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[GM]/ ) { $calendar = 6 }
    }
    elsif ( $month[$mon] eq 'May' ) {  
	if ( $year_code{$year} =~ /[DJ]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[FL]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[CI]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[GM]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[BH]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[AN]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[EK]/ ) { $calendar = 6 }
    }
    elsif ( $month[$mon] eq 'June' ) {  
	if ( $year_code{$year} =~ /[AN]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[CI]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[GM]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[DJ]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[FL]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[EK]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[BH]/ ) { $calendar = 6 }
    }
    elsif ( $month[$mon] eq 'July' ) {  
	if ( $year_code{$year} =~ /[FL]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[AN]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[EK]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[BH]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[DJ]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[CI]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[GM]/ ) { $calendar = 6 }
    }
    elsif ( $month[$mon] eq 'August' ) {  
	if ( $year_code{$year} =~ /[CI]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[EK]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[BH]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[FL]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[AN]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[GM]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[DJ]/ ) { $calendar = 6 }
    }
    elsif ( $month[$mon] eq 'September' ) {  
	if ( $year_code{$year} =~ /[GM]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[BH]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[FL]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[CI]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[EK]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[DJ]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[AN]/ ) { $calendar = 6 }
    }
    elsif ( $month[$mon] eq 'October' ) {  
	if ( $year_code{$year} =~ /[EK]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[GM]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[DJ]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[AN]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[CI]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[BH]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[FL]/ ) { $calendar = 6 }
    }
    elsif ( $month[$mon] eq 'November' ) {  
	if ( $year_code{$year} =~ /[BH]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[DJ]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[AN]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[EK]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[GM]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[FL]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[CI]/ ) { $calendar = 6 }
    }
    elsif ( $month[$mon] eq 'December' ) {  
	if ( $year_code{$year} =~ /[GM]/ ) { $calendar = 5 }
	elsif ( $year_code{$year} =~ /[BH]/ ) { $calendar = 0 }
	elsif ( $year_code{$year} =~ /[FL]/ ) { $calendar = 4 }
	elsif ( $year_code{$year} =~ /[CI]/ ) { $calendar = 1 }
	elsif ( $year_code{$year} =~ /[EK]/ ) { $calendar = 3 }
	elsif ( $year_code{$year} =~ /[DJ]/ ) { $calendar = 2 }
	elsif ( $year_code{$year} =~ /[AN]/ ) { $calendar = 6 }
    }

    $perpetual_calendar = $calendar; 
    $perpetual_calendar;			# Return value for subroutine
}

sub receive_file_contents {
#       
# Returns the contents of a file. 
# Takes a filename as an argument.
#       
    local($file_nickname, $filename, @file_contents);
    $file_nickname = $_[0];
    
    $filename = $configuration_file{$file_nickname};

    open(FILE, $filename) || &error_html("in the filename");
    while (<FILE>) { push(file_contents, $_); } 
    close(FILE);
        
    @file_contents;     # Return value for subroutine &receive_file_contents
}       

sub credit_comment {
#           
# Prints credits.  Please don't remove or change the comment.
#   
    print "<!-- calendar.pl ($_[0]) was written by Collin Forbes in August, 1996 -->\n";

    # There is no meaningful return value for this subroutine.
}       

sub error_html {
# 
# Prints a meaningful error message in HTML, takes an argument
# briefly and crypticly describing the nature of the error.
#   
    $error_string = $_[0]; 
    
    print "Content-type: text/html\n\n";
        
    print <<HTML;
<HTML>
<HEAD>
<TITLE>ERROR<TITLE>
</HEAD>
<BODY>
<h1>ERROR: There was an error $error_string</h1>
</BODY> 
</HTML> 
HTML
 
    exit; 
} 


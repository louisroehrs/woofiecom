#!/usr/local/bin/perl
#
# add-a-date.pl -- A CGI script to add a line containing calendar information 
#		   to a file by virtue of a password-protected form.
#
# Written by Collin Forbes in April, 1996 as "password-form.pl".
# Rewritten and modified by Collin Forbes in August, 1996.
#
# Use this script as the POST action of a form with the following fields
#
# <input name=password> (required)  The password that attempts to verify
#	that the user who has submited the form is authorized to add dates
#	to the calendar.
#
# <input name=file> (sort-of-required) The "nickname" of the configuration
#	file to use.  This file contains configuration information as well
#	as dates or events in the following format:
#		"year<tab>month<tab>day<tab>event<newline>"
#	You can use "any" in any of the fields to make an event	repeat.
#
# <input name=year> (optional)  The year of the event.  Either a numeric
#	value (70-149) or a keyword "any", "next", "current", or "previous"
#	(if you want to be retroactive).  If ommitted, defaults to the 
#	current year.
#
# <input name=month> (optional) The month of the event.  Either a numeric
#	value (1-12) or a keyword "any", "next", "current", or "previous"
#	(if you want to be retroactive).  If ommitted, defaults to the
#	current month.
#
# <input name=day> (required) The day of the event.  Either a numeric
#	value (1-31) or "any".  No default, error if this is ommitted.
#
# Configuration Section ------------------------------------------

$user_passwd = "23TPVefOt0YPE";
#
# $user_passwd is the encrypted password to match against.  To change
# this password cut and paste the result of:
#	echo [password] | perl -ne 'print crypt($_, "ab") . "\n"';
# (where [password] is your new password) 
#
# Or cut and paste your password from the /etc/passwd file.

%configuration_file = (
        '' => '/home/collinf/public_html/scripts/calendar-2.2/config.txt',
        'calendar' => '/home/collinf/public_html/scripts/calendar-2.2/config.txt',
        'padded_cells' => '/home/collinf/public_html/scripts/calendar-2.2/config.txt',
        );
#
# This array should be *identical* to the array of the same name in the 
# calendar.pl script.
# 
# You can use the different "nicknames" to point to different configuration
# files.  The "=>" is a perl5 synonym for a comma.  Change them to commas  
# to use this script under perl4.  You will also have to change various
# "and" boolean operators to "&&" in numerous if statements.
#

$password_form_url = 'http://kuoi.asui.uidaho.edu/~collinf/scripts/calendar-2.2/password-form.html';

#
# $pssword_form_url is the URL of the password-protected form.  This
# variable is used to provide a link back to the form on the success page.
#
# End Configuration Section --------------------------------------

main: {

    &receive_form_information();			# Creates %FORM

    $input_passwd =  $FORM{'password'};
    $form_event = $FORM{'event'};
    $file_nickname = $FORM{'file'};

    $config_filename = $configuration_file{$file_nickname};

    #
    # Do some preliminary validation that info was in the form.
    #
    if ( $config_filename eq '' ) { &error_html("with the \"file\" field"); }
    if ( $form_event eq '' ) { &error_html("with the \"event\" field") }
    if ( $input_passwd eq '' ) { &error_html("with \"password\" form field") }

    if ( &verify_password($input_passwd, $user_passwd) eq "true" ) {
	&add_date_to_file($config_filename);
	&print_success($password_form_url);
    }    
    else { &error_html("in the password you gave, it was not right"); }
}

sub add_date_to_file {
#
# Adds the date information to the end of the file given as an argument.
#
# Global variables:	Uses %FORM
#
    local (	$filename, $form_day, $form_year, $form_mon, $form_event,
		$sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst);

    $filename = $_[0]; 

    $form_mon = $FORM{'mon'};		# 
    $form_year = $FORM{'year'};		# Get informaton from the form
    $form_day = $FORM{'day'};		#
    $form_event = $FORM{'event'};	#

    ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdist) = localtime(time);

    if ( $form_day !~ m/^\d+$/ ) {
	if ( $form_day !~ m/any/i ) { &error_html("with the \"day\" field"); }
    }

    #
    # Convert form dates/keywords into real values.  
    #
    # Bounds checking on the numeric values is not performed.  If you want
    # to put garbage into your configuration file, you may do so--it won't
    # hurt the calendar script.
    #
    # Years are either numeric (70-149) or one of the keywords
    #	"any", "current", "next", or "previous".
    #
    if ( $form_mon !~ m/^\d+$/ ) {
	if ( $form_mon eq '' ) { $mon;   }		# Default behavior
	elsif ( $form_mon =~ m/any/i )   { $mon = 'any'; }
	elsif ( $form_mon =~ m/cur/i ) 	 { $mon;   }	# No change
	elsif ( $form_mon =~ m/next/i )  { $mon++; }	# Increment
        elsif ( $form_mon =~ m/prev/i )  { $mon--; } 	# Decrement
	else { &error_html("with the \"mon\" field"); }	# Otherwise an error
    }
    else { $mon = $form_mon; }
    #
    # Months are either numeric (1-12) or one of the keywords 
    #	"any", "current", "next", or "previous".
    #
    if ( $form_year !~ m/^\d+$/ ) {
	if ( $form_year eq '' ) { $year;   }		# Default behavior
	elsif ( $form_year =~ m/any/i )  { $year = 'any'; }
	elsif ( $form_year =~ m/cur/i )  { $year;    }	# No change
	elsif ( $form_year =~ m/next/i ) { $year++;  }	# Increment
	elsif ( $form_year =~ m/prev/i ) { $year--;  }	# Decrement
	else { &error_html("with the \"year\" field"); } # Otherwise an error
    }
    else { $year = $form_year; }
    #
    # Days are either numeric (1-31) or the keyword "any"
    #
    if ( $form_day !~ m/^\d+$/ ) {
	if ( $form_day =~ m/^any$/i ) { $mday = "any" }
	else { &error_html("with the \"day\" field"); }
    }
    else { $mday = $form_day; }

    open(FILE, ">>$filename") || &error_html("opening file: \"$filename\"");
    print FILE "$year\t$mon\t$mday\t$form_event\n";
    close FILE;
}

sub print_success {
#
# Prints a confirmation message after successfully writing the date.
#
# Global variables:	Uses "$config_filename"
#
    local($url);
    $url = $_[0];

    print "Content-type: text/html\n\n";

    print "<head><title>Success!</title></head>\n";
    print "<body><h1>Success!<br>\n";
    print "The date was saved to \"$config_filename\"<h1>\n";
    print "<h2><a href=\"$url\">Return to the Add-A-Date form</a></h2>\n";
    print "</body></html>\n";
}

sub verify_password {
#
# Compares two passwords.  The first is the password given by the user in
# the form, the second is the encrypted password.  
#
# Returns "true" if match, "false" if they don't match.
#
    local($salt, $user_passwd, $input_passwd, $verify_passwd);
    $input_passwd = $_[0];
    $user_passwd =  $_[1];

    $salt = substr($user_passwd, 0, 2);
    if ( crypt($input_passwd, $salt) eq "$user_passwd" ) {
	$verify_passwd = "true";
    }
    else { $verify_passwd = "false"; }

    $verify_passwd;	# Return value for subroutine &verify_password
}

sub receive_form_information {
#
# Gets the form information and converts it into readable form
# (returns an associative array).
#
# This was directly lifted from Matt Wright's FormMail script.
#
# Global Variable:      Creates %FORM
#
    local($buffer, @pairs, $pair, $name, $value);

    # Get the input
    read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});

    # Split the name-value pairs
    @pairs = split(/&/, $buffer);

    foreach $pair (@pairs) {
        ($name, $value) = split(/=/, $pair);

        $value =~ tr/+/ /;
        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
        $name =~ tr/+/ /;
        $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;

        $FORM{$name} = $value;
    }

    %FORM;      # Return value for subroutine &receive_form_information
}


sub error_html {
#
# Prints a meaningful error message in HTML, takes an argument
# briefly and crypticly describing the nature of the error.
#
    $error_string = $_[0];
 
    print "Content-type: text/html\n\n";
 
    print <<HTML;
<HTML>
<HEAD>
<TITLE>ERROR<TITLE>
</HEAD>
<BODY>
<h1>ERROR: There was an error $error_string</h1>
</BODY>
</HTML>
HTML
 
    exit;
}

